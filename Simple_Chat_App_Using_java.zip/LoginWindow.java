import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginWindow extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginWindow frame = new LoginWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginWindow() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		setResizable(false);
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300, 380);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(64, 53, 165, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(112, 34, 59, 20);
		contentPane.add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setBounds(64, 121, 165, 28);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(140, 121, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblIpAddress = new JLabel("IP Address");
		lblIpAddress.setBounds(110, 106, 74, 14);
		contentPane.add(lblIpAddress);
		
		JLabel lblPort = new JLabel("Port");
		lblPort.setBounds(126, 178, 41, 20);
		contentPane.add(lblPort);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(64, 199, 165, 28);
		contentPane.add(textField_2);
		
		JLabel lbleg = new JLabel("(eg. 192.168.1.2)");
		lbleg.setBounds(100, 146, 93, 20);
		contentPane.add(lbleg);
		
		JLabel lbleg_1 = new JLabel("(eg. 8192)");
		lbleg_1.setBounds(111, 231, 71, 20);
		contentPane.add(lbleg_1);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String name = textField.getText();
			String address = textField_1.getText();
			int  port = Integer.parseInt(textField_2.getText());
			login(name,address,port);
			
		}

		
		});
		btnNewButton.setBounds(100, 300, 89, 23);
		contentPane.add(btnNewButton);
	}
	private void login(String name, String address, int port) {
		// TODO Auto-generated method stub
		dispose();
		new Client(name,address,port);
		
	}
}
